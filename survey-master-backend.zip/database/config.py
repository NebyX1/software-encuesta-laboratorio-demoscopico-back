from dotenv import load_dotenv
import os

load_dotenv()

user = os.environ.get("MYSQL_USER")
password = os.environ.get("MYSQL_PASSWORD")
host = os.environ.get("MYSQL_HOST")
db_name = os.environ.get("MYSQL_DATABASE")

DATABASE_CONNECTION_URI = f'mysql+pymysql://{user}:{password}@{host}/{db_name}'
